# NotEnoughCoins

<img alt="Downloads" src="https://img.shields.io/github/downloads/mindlesslydev/notenoughcoins/total.svg" />
<img alt="Downloads" src="https://img.shields.io/endpoint.svg?url=https%3A%2F%2Fshieldsio-patreon.vercel.app%2Fapi%3Fusername%3Drobothanzo%26type%3Dpatrons" />

A SkyBlock Flipping Mod.

- `/nec` - Shows the config GUI
- `/nec help` - Shows the help message containing all the subcommands and their usage
- `/nec toggle` - Enables the mod to return a list of suggested items to flip whenever one is found.
- Discord - https://discord.gg/b3JBsh8fEd

# We are not liable for any coins you lost by buying items without checking, flips aren't always perfect
